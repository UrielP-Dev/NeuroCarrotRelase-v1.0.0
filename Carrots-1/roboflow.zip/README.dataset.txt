# Carrots > 2024-06-11 12:30pm
https://universe.roboflow.com/test-pgigc/carrots-j885y

Provided by a Roboflow user
License: CC BY 4.0

